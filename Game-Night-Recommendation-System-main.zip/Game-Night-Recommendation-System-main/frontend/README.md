### TO Run the React JS application

1. `npm install`
2. `npm start`

### Packages Installed

1. Material UI - for implementing UI components.
2. Axios - for interating with backend and others services using RESTful APIS.
3. Scss - for css.

